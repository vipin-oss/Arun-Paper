# Simple article version

This folder contains the same paper written with the standard LaTeX
`article` class instead of the Elsevier `elsarticle` class used in
`../manuscript/main.tex`.

Regenerate it from the master manuscript with:

```bash
python3 ../tools/build_simple_article.py
```

Compile it with:

```bash
pdflatex -jobname=Paper2_Simple_Article main.tex
bibtex Paper2_Simple_Article
pdflatex -jobname=Paper2_Simple_Article main.tex
pdflatex -jobname=Paper2_Simple_Article main.tex
```

The body of `main.tex` is generated unchanged from the master manuscript;
only the document class, title block, keyword/MSC presentation, and
bibliography style are adapted for a plain article layout.
