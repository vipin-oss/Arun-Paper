# Single-column build

This project compiles the paper in **ONE column** (single spaced).

* **Main document:** `main.tex` — do not change it unless you want another layout.
  On Overleaf: Menu → Main document → `main.tex`, then Recompile.
* `body.tex` — the manuscript text. Edit the paper here, not in `main.tex`.
* `references.bib` — 31 references; the build uses BibTeX automatically.
* `figures/` — the three vector figures.

Other layouts of the same paper (same `body.tex`, nothing else changes):

| want | where |
|---|---|
| two-column IEEE journal layout | `paper/ieee/main.tex` in the repository |
| single column, double spaced (IEEE review format) | `paper/ieee/main_peerreview.tex` |

No IEEEtran.cls is required for this single-column build.
